package com.example.recyclerviewproject;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.ClipData;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteStatement;
import android.os.Bundle;
import android.print.PrinterId;
import android.text.TextUtils;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

public class MainActivity extends AppCompatActivity implements AdapterView.OnItemSelectedListener {

    String prioritySpinner = "H";
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater menuInflater = getMenuInflater();
        menuInflater.inflate(R.menu.priority_menu,menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        super.onOptionsItemSelected(item);
        switch (item.getItemId()){
            case R.id.high:
                updateRecyclerViewH();
                return true;
            case R.id.medium:
                updateRecyclerViewM();
                return true;
            case R.id.low:
                updateRecyclerViewL();
                return true;
            case R.id.all:
                updateRecyclerView();
            default:
                return false;
        }
    }

    static SQLiteDatabase database;

    private RecyclerView mRecycleView;
    static ExampleAdapter mAdapter;
    private RecyclerView.LayoutManager layoutManager;
    static ArrayList<Example_item> mexampleList;

    static Button buttonInsert;
    private EditText inputTitle;
    private EditText inputDescription;
    private Spinner spinner;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        database = this.openOrCreateDatabase("Notes",MODE_PRIVATE,null);
        database.execSQL("CREATE TABLE IF NOT EXISTS notes(id INTEGER PRIMARY KEY,title VARCHAR,content VARCHAR,date VARCHAR,priority VARCHAR)");

        createExampleList();
        buildRecyclerView();
        setupButton();
        updateRecyclerView();
    }

    public void insertItem(int position){
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("HH:mm dd/MM/yy");
        mexampleList.add(position-1,new Example_item(inputTitle.getText().toString(),simpleDateFormat.format(new Date()),prioritySpinner,inputDescription.getText().toString()));
        mAdapter.notifyItemInserted(position-1);
        setDatabase();
    }


    public void createExampleList(){
        mexampleList = new ArrayList<Example_item>();
    }

    public void buildRecyclerView(){
        mRecycleView = findViewById(R.id.recyclerView);
        mRecycleView.setHasFixedSize(true);
        layoutManager = new LinearLayoutManager(this);
        mAdapter = new ExampleAdapter(mexampleList);
        mRecycleView.setLayoutManager(layoutManager);
        mRecycleView.setAdapter(mAdapter);

        mAdapter.setOnItemClickListener(new ExampleAdapter.OnItemClickedListener() {
            @Override
            public void onItemClick(int position) {
                Intent intent = new Intent(getApplicationContext(),ItemActivity.class);
                intent.putExtra("id",position);
                startActivity(intent);
            }

            @Override
            public void onDeleteClick(final int position) {
                new AlertDialog.Builder(MainActivity.this)
                        .setIcon(android.R.drawable.alert_light_frame)
                        .setTitle("Are You Sure?")
                        .setMessage("The Command yes is irreversible")
                        .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {

                                mexampleList.remove(position);
                                mAdapter.notifyItemRemoved(position);
                                setDatabase();
                                updateRecyclerView();
                            }
                        })
                        .setNegativeButton("Not Sure",null)
                        .show();
            }
        });
    }
    public void setupButton() {
        buttonInsert = findViewById(R.id.insertButton);
        //editTextInsert = findViewById(R.id.insertEditText);

        inputTitle = findViewById(R.id.inputTitleEditText);
        inputDescription = findViewById(R.id.DescriptionEditText);
        spinner = findViewById(R.id.spinner);
        ArrayAdapter<CharSequence> spinnera = ArrayAdapter.createFromResource(this,R.array.priorities,android.R.layout.simple_spinner_item);
        spinnera.setDropDownViewResource(R.layout.support_simple_spinner_dropdown_item);
        spinner.setAdapter(spinnera);
        spinner.setOnItemSelectedListener(this);

        buttonInsert.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (!TextUtils.isEmpty(inputTitle.getText())  && !prioritySpinner.equals("")) {
                    int position = 1;
                    if(!TextUtils.isEmpty(inputDescription.getText()))
                        inputDescription.setText(inputTitle.getText());
                    if (position <= mexampleList.size() + 1) {
                        insertItem(position);
                        Toast.makeText(MainActivity.this, "ITEM SAVED!", Toast.LENGTH_SHORT).show();
                        InputMethodManager inputMethodManager = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                        assert inputMethodManager != null;
                        inputMethodManager.hideSoftInputFromWindow(inputTitle.getWindowToken(),0);
                        inputTitle.getText().clear();
                        inputDescription.getText().clear();
                    } else
                        Toast.makeText(MainActivity.this, "Input Valid Index", Toast.LENGTH_SHORT).show();
                } else
                    Toast.makeText(MainActivity.this, "Input All the Parameters", Toast.LENGTH_SHORT).show();
            }
        });
    }

    static public void setDatabase(){

        database.execSQL("DELETE FROM notes");
        for ( int i = 0 ; i < mexampleList.size() ; ++i){
            String sql = "INSERT INTO notes (title,content,date,priority) VALUES (?,?,?,?)";
            SQLiteStatement statement = database.compileStatement(sql);
            statement.bindString(1,mexampleList.get(i).getTittleText());
            statement.bindString(2,mexampleList.get(i).getDescriptionText());
            statement.bindString(3,mexampleList.get(i).getDatetimeText());
            statement.bindString(4,mexampleList.get(i).getPriorityText());
            statement.execute();
        }
    }

    static public void updateRecyclerView() {
        Cursor c = database.rawQuery("SELECT * FROM notes", null);

        int titleIndex = c.getColumnIndex("title");
        int contentIndex = c.getColumnIndex("content");
        int dateIndex = c.getColumnIndex("date");
        int priorityIndex = c.getColumnIndex("priority");

        if (c.moveToFirst()) {
            mexampleList.clear();
            do {
                mexampleList.add(new Example_item(c.getString(titleIndex), c.getString(dateIndex), c.getString(priorityIndex), c.getString(contentIndex)));
                c.moveToNext();
            } while (!c.isAfterLast());
            mAdapter.notifyDataSetChanged();
        }
        buttonInsert.setEnabled(true);
    }

    public void updateRecyclerViewH(){
        Toast.makeText(MainActivity.this,"Showing High Priority Data!",Toast.LENGTH_SHORT).show();
        Cursor c = database.rawQuery("SELECT * FROM notes WHERE priority = 'H'",null);
        int titleIndex = c.getColumnIndex("title");
        int contentIndex = c.getColumnIndex("content");
        int dateIndex = c.getColumnIndex("date");
        int priorityIndex = c.getColumnIndex("priority");
        mexampleList.clear();
        c.moveToFirst();
        while (!c.isAfterLast()){
            mexampleList.add(new Example_item(c.getString(titleIndex), c.getString(dateIndex), c.getString(priorityIndex), c.getString(contentIndex)));
            c.moveToNext();
        }
        mAdapter.notifyDataSetChanged();
        buttonInsert.setEnabled(false);
    }

    public void updateRecyclerViewM(){
        Toast.makeText(MainActivity.this,"Showing Medium Priority Data!",Toast.LENGTH_SHORT).show();
        Cursor c = database.rawQuery("SELECT * FROM notes WHERE priority = 'M'",null);
        int titleIndex = c.getColumnIndex("title");
        int contentIndex = c.getColumnIndex("content");
        int dateIndex = c.getColumnIndex("date");
        int priorityIndex = c.getColumnIndex("priority");
        mexampleList.clear();
        c.moveToFirst();
        while (!c.isAfterLast()){
            mexampleList.add(new Example_item(c.getString(titleIndex), c.getString(dateIndex), c.getString(priorityIndex), c.getString(contentIndex)));
            c.moveToNext();
        }
        mAdapter.notifyDataSetChanged();
        buttonInsert.setEnabled(false);
    }

    public void updateRecyclerViewL(){
        Toast.makeText(MainActivity.this,"Showing Low Priority Data!",Toast.LENGTH_SHORT).show();
        Cursor c = database.rawQuery("SELECT * FROM notes WHERE priority = 'L'",null);
        int titleIndex = c.getColumnIndex("title");
        int contentIndex = c.getColumnIndex("content");
        int dateIndex = c.getColumnIndex("date");
        int priorityIndex = c.getColumnIndex("priority");
        mexampleList.clear();
        c.moveToFirst();
        while (!c.isAfterLast()){
            mexampleList.add(new Example_item(c.getString(titleIndex), c.getString(dateIndex), c.getString(priorityIndex), c.getString(contentIndex)));
            c.moveToNext();
        }
        mAdapter.notifyDataSetChanged();
        buttonInsert.setEnabled(false);
    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        prioritySpinner = parent.getItemAtPosition(position).toString();
    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {
        prioritySpinner = "H";
    }
}

package com.example.recyclerviewproject;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.sqlite.SQLiteStatement;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.Date;

public class ItemActivity extends AppCompatActivity {

    private EditText TitleText;
    private EditText priorityText;
    private EditText descriptionText;
    private TextView datetimetext;
    private Button editButton;
    boolean want_to_edit;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_item);

        TitleText = findViewById(R.id.TitleTextitem);
        priorityText = findViewById(R.id.priorityitemText);
        descriptionText = findViewById(R.id.DescriptionTextitem);
        editButton = findViewById(R.id.buttonitem);
        datetimetext = findViewById(R.id.DateTextitem);
        Intent intent = getIntent();

        final int id = intent.getIntExtra("id",0);
        TitleText.setText(MainActivity.mexampleList.get(id).getTittleText());
        priorityText.setText(MainActivity.mexampleList.get(id).getPriorityText());
        descriptionText.setText(MainActivity.mexampleList.get(id).getDescriptionText());
        datetimetext.setText(MainActivity.mexampleList.get(id).getDatetimeText());

        TitleText.setEnabled(false);
        priorityText.setEnabled(false);
        descriptionText.setEnabled(false);
        want_to_edit = true;
        editButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               if(want_to_edit)
               {
                   TitleText.setEnabled(true);
                   priorityText.setEnabled(true);
                   descriptionText.setEnabled(true);
                   editButton.setText("SAVE");
                   want_to_edit = false;
               }
               else {
                   TitleText.setEnabled(false);
                   priorityText.setEnabled(false);
                   descriptionText.setEnabled(false);
                   Toast.makeText(ItemActivity.this,"Saved!",Toast.LENGTH_SHORT).show();
                   want_to_edit = true;
                   editButton.setText("EDIT");
                   SimpleDateFormat simpleDateFormat = new SimpleDateFormat("HH:mm dd/MM/yy");
                   datetimetext.setText(simpleDateFormat.format(new Date()));
                   MainActivity.mexampleList.set(id,new Example_item(TitleText.getText().toString(),simpleDateFormat.format(new Date()),priorityText.getText().toString(),descriptionText.getText().toString()));
                   MainActivity.mAdapter.notifyItemChanged(id);
                   MainActivity.setDatabase();
                   MainActivity.updateRecyclerView();

               }

            }
        });

    }

}

package com.example.recyclerviewproject;

import android.text.Editable;

public class Example_item {

    private String tittleText;
    private String datetimeText;
    private String priorityText;
    private String descriptionText;


    public Example_item(String Text1,String Text2,String Text3,String Text4){
        tittleText = Text1;
        datetimeText = Text2;
        priorityText = Text3;
        descriptionText = Text4;
    }

    public String getTittleText(){
        return tittleText;
    }
    public String getDatetimeText(){
        return datetimeText;
    }
    public String getPriorityText(){
        return priorityText;
    }
    public String getDescriptionText(){ return descriptionText; }
}

package com.example.todolist;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class EditTaskDesk extends AppCompatActivity {

    TextView titlepage,titleText,descriptionText,timelineText;
    EditText titleEdText,descriptionEdText,timelineEdText;
    Button btnUpdateTask,btnDeleteTask;
    DatabaseReference reference;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_task_desk);
        titlepage = findViewById(R.id.newUpdateTitlePageText);
        titleText = findViewById(R.id.newUpdateTitleText);
        descriptionText = findViewById(R.id.newUpdateDescriptionText);
        timelineText = findViewById(R.id.newUpdateTimeText);
        titleEdText = findViewById(R.id.newUpdateTitleEditText);
        descriptionEdText = findViewById(R.id.newUpdateDescriptionEditText);
        timelineEdText = findViewById(R.id.newUpdateDateTimeEditText);
        btnUpdateTask= findViewById(R.id.btnUpdateTask);
        btnDeleteTask= findViewById(R.id.btnDeleteTask);


        // getting previous values
        titleEdText.setText(getIntent().getStringExtra("titledoes"));
        descriptionEdText.setText(getIntent().getStringExtra("descdoes"));
        timelineEdText.setText(getIntent().getStringExtra("datedoes"));
        final String getKeydoes = getIntent().getStringExtra("keydoes");

        reference = FirebaseDatabase.getInstance().getReference().child("DoesApp").child("Does"+getKeydoes);
        // deletion
        btnDeleteTask.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new AlertDialog.Builder(EditTaskDesk.this)
                        .setTitle("Are You Sure?")
                        .setMessage("The Delete Choice is Irreversible")
                        .setIcon(android.R.drawable.alert_dark_frame)
                        .setPositiveButton("YES", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                reference.removeValue().addOnCompleteListener(new OnCompleteListener<Void>() {
                                    @Override
                                    public void onComplete(@NonNull Task<Void> task) {
                                        if(task.isSuccessful()){
                                            Intent a = new Intent(EditTaskDesk.this,MainActivity.class);
                                            startActivity(a);
                                        }else{
                                            Toast.makeText(EditTaskDesk.this,"Failed For some Reason",Toast.LENGTH_SHORT).show();
                                        }
                                    }
                                });
                            }
                        })
                        .setNegativeButton("NO",null)
                        .show();
            }
        });

        // now button addition
        btnUpdateTask.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                reference.addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        dataSnapshot.getRef().child("titledoes").setValue(titleEdText.getText().toString());
                        dataSnapshot.getRef().child("descdoes").setValue(descriptionEdText.getText().toString());
                        dataSnapshot.getRef().child("datedoes").setValue(timelineEdText.getText().toString());
                        dataSnapshot.getRef().child("keydoes").setValue(getKeydoes);
                        Intent a = new Intent(EditTaskDesk.this,MainActivity.class);
                        startActivity(a);
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {

                    }
                });
            }
        });

    }
}

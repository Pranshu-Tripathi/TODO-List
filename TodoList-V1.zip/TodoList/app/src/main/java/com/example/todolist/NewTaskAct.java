package com.example.todolist;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.Random;

public class NewTaskAct extends AppCompatActivity {

    TextView titlepage,titleText,descriptionText,timelineText;
    EditText titleEdText,descriptionEdText,timelineEdText;
    Button btnSaveTask,btnCancelTask;
    Integer num = new Random().nextInt();
    String keydoes  = Integer.toString(num);

    DatabaseReference reference;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_new_task);
        titlepage = findViewById(R.id.newTitlePageText);
        titleText = findViewById(R.id.newTitleText);
        descriptionText = findViewById(R.id.newDescriptionText);
        timelineText = findViewById(R.id.newTimeText);
        titleEdText = findViewById(R.id.newTitleEditText);
        descriptionEdText = findViewById(R.id.newDescriptionEditText);
        timelineEdText = findViewById(R.id.newDateTimeEditText);
        btnSaveTask= findViewById(R.id.btnSaveTask);
        btnCancelTask= findViewById(R.id.btnCancelTask);

        btnSaveTask.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // insert new data to firebase
                reference = FirebaseDatabase.getInstance().getReference().child("DoesApp").child("Does"+num);
                reference.addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        dataSnapshot.getRef().child("titledoes").setValue(titleEdText.getText().toString());
                        dataSnapshot.getRef().child("descdoes").setValue(descriptionEdText.getText().toString());
                        dataSnapshot.getRef().child("datedoes").setValue(timelineEdText.getText().toString());
                        dataSnapshot.getRef().child("keydoes").setValue(keydoes);
                        Intent a = new Intent(NewTaskAct.this,MainActivity.class);
                        startActivity(a);
                        Toast.makeText(NewTaskAct.this,"Saved!",Toast.LENGTH_SHORT).show();
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {

                    }
                });

            }
        });
        btnCancelTask.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent a = new Intent(NewTaskAct.this,MainActivity.class);
                startActivity(a);
            }
        });
    }
}
